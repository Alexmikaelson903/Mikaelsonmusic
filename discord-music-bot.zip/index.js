// index principal do bot
require('dotenv').config();
console.log('Bot iniciado');